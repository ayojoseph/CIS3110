CIS3110 Assignment 1
Author: Love Joseph (0890515)

References: 
	Basic shell structure idea taken from Stephen Brennan @ 
	http://stephen-brennan.com/2015/01/16/write-a-shell-in-c/

	*around 35% of program structure.

A1- Create a Shell

-part one completed
-part two: file out is implemented, file input is a work in progress
	- ".txt" is added to thee end of file name in output.
-part 3 cd command implemented

-



