CIS3110 Assignment 2
Author: Love Joseph (0890515)

References: 
	The Human Brain :'(

A2- Cpu SIMULATION

-only FCFS really implemented
-no detailed mode.

-